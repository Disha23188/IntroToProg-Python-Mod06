#---------------------------------------------------------------------------------- #
#Title: Assignment06
#Desc: Functions
#Change Log: (Who, When, What)
#Disha, 9/9/2024,Created Script
#---------------------------------------------------------------------------------- #
import json
from itertools import filterfalse
from json import JSONDecodeError
from typing import TextIO, IO

MENU: str='''\n--- Course Registration Program ---
Select from the following menu:
    1. Register a Student for a Course
    2. Show current data
    3. Save data to a file
    4. Exit the program
-----------------------------------------'''

FILE_NAME: str = "Enrollments.json"

# Define the data Variables:
students: list = [] # a table of student data.
menu_choice: str # Holds the choice made by the user.
file: TextIO = None

# Extract the data from the file.

class FileProcessor:

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        '''
        This function reads the data from a json file and returns a list of dictionaries.
        :param file_name: string, the name of the file to read.
        :return: The student table which is of type list.
        '''

        try:
            file = open(file_name, "r")
            student_data = json.load(file)
        except FileNotFoundError as e:
            IOProcessor.output_error_messages(message="Error: There was an error reading the file", error=e)
            IOProcessor.output_error_messages(message="Creating file since it doesn't exist.", error=e)
            file = open(file_name, "w")
            json.dump(student_data, file)
        finally:
            if not file.closed:
                file.close()
        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        """ This function writes data to a json file with data from a list of dictionary rows"""
        try:
            file = open(file_name, "w")
            json.dump(student_data, file)
            file.close()
            IOProcessor.output_student_and_course_names(student_data=student_data)
        except Exception as e:
            message = "Error: There was a problem with writing to the file.\n"
            message += "Please check that the file is not open by another program."
            IOProcessor.output_error_messages(message=message,error=e)
        finally:
            if file.closed == False:
                file.close()

class IOProcessor:
    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        print(message, end="\n\n")
        if error is not None:
            print("--Technical Error Message--")
            print(error, error.__doc__, type(error), sep="\n")

    @staticmethod
    def output_menu(menu: str):
        ''' This function displays the menu of choices to the user
        '''
        print() # Adding extra space to make it look nicer.
        print(menu)
        print() # Adding extra space to make it look nicer.

    @staticmethod
    def input_menu_choice(menu_choice: str):
        try:
            menu_choice = input("What would you like to do: ")
            if menu_choice not in ['1', '2', '3','4']:
                raise Exception("Please, choose only 1,2,3 or 4")
        except Exception as e:
            IOProcessor.output_error_messages(menu_choice, 'Invalid choice')
        return menu_choice

    @staticmethod
    def output_student_and_course_names(student_data: list):
        ''' This function displays the student and course name to the user.
        '''

        print("_" * 50)
        for student in student_data:
            print(f'student {student["first_name"]} {student["last_name"]} is enrolled in {student["course_name"]}')
        print("_" * 50)

    @staticmethod
    def input_student_data(student_data: list):
        ''' This function gets the student's first name and last name, with a course name from the user.
        :return: list'''
        try:
            # Input the data:
            student_first_name = input("Enter the student's first name: ")
            if not student_first_name.isalpha():
                raise ValueError("Student First Name must be alphabetic")
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise ValueError("Student Last Name must be alphabetic")
            course_name = input("Please enter the name of the course: ")
            students = {'first_name': student_first_name, 'last_name': student_last_name,
                            'course_name': course_name}
            student_data.append(students)
            print += (f"{student_first_name},{student_last_name},{course_name}\n")
        except ValueError as e:
            IOProcessor.output_error_messages(message='Invalid input', error=e)
        except Exception as e:
            IOProcessor.output_error_messages(message='There was a problem with your entered data.', error=e)
        return student_data

# When the program starts, read the file data into a list of lists (table)
students= FileProcessor.read_data_from_file(file_name=FILE_NAME, student_data=students)

    # Present and process the data.
while True:

    IOProcessor.output_menu(menu=MENU)

    menu_choice = IOProcessor.input_menu_choice(menu_choice=MENU)

    # Input user data:
    if menu_choice == '1':  # This will not work if it is an integer!
        students = IOProcessor.input_student_data(students)
        continue

    # Present the current data:
    elif menu_choice == '2': # Process the data to create and display a custom message.
        IOProcessor.output_student_and_course_names(students)
        continue

    # Save the data to a file.
    elif menu_choice == '3':
        FileProcessor.write_data_to_file(file_name=FILE_NAME, student_data=students)
        continue

    # Stop the loop:
    elif menu_choice == '4':
        print("Program Ended")
        break

    else:
        print("You made invalid choice. Please try again. ")

